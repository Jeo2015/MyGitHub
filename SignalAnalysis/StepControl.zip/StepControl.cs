﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SignalAnalysis
{
    class StepControl
    {
        public static bool TestItem()
        {
            return true;
        }
        static Step CurrentStep = new Step();
        private static int StepsExcuteLoopNum = 0;
        public static bool ExcuteSteps(Steps steps)
        {
            StepsExcuteLoopNum++;
            for (int i = 0; i < steps.StepsNum; i++)
            {
                if (IsNeedJump())
                {
                    int _jumpStepNum = SystemInfo.GetValue<int>("JumpStepNum");
                    i = _jumpStepNum;
                    SystemInfo.SetValue<bool>("IsJump", false);//关闭跳跃模式
                    break;
                }
                CurrentStep = steps.StepList[i];
                if (CurrentStep.CategoryName== "流程管控")
                {
                    int j = 0;
                    switch (CurrentStep.FounctionName)
                    {
                        case "if (bool condition)":
                            Steps ConditionStep = new Steps();
                            Steps IfSteps = new Steps();
                            Steps ElseSteps = new Steps();
                            ConditionStep.StepsNum = 1;
                            ConditionStep.StepList.Add(steps.StepList[i + 1]);
                            while(steps.StepList[i+j].FounctionName != "ifend" &&
                                steps.StepList[i+j].FounctionName != "else")
                            {
                                IfSteps.StepsNum++;
                                IfSteps.StepList.Add(steps.StepList[i + j]);
                                j++;
                            }
                            if (steps.StepList[i + j].FounctionName == "else")
                            {
                                ElseSteps.StepsNum++;
                                ElseSteps.StepList.Add(steps.StepList[i + j]);
                                j++;
                            }
                            bool condition = ExcuteSteps(ConditionStep);
                            if (condition)
                            {
                                ExcuteSteps(IfSteps);
                            }
                            else
                            {
                                ExcuteSteps(ElseSteps);
                            }
                            i = i + j;
                            break;
                        case "while (bool condition)":
                            Steps WhileCondition = new Steps();
                            Steps CircleSteps = new Steps();
                            WhileCondition.StepsNum = 1;
                            WhileCondition.StepList.Add(steps.StepList[i + 1]);
                            while(steps.StepList[i+j].FounctionName != "whileend")
                            {
                                CircleSteps.StepsNum++;
                                CircleSteps.StepList.Add(steps.StepList[i + j]);
                                j++;
                            }
                            bool whileCondition = ExcuteSteps(WhileCondition);
                            while (whileCondition)
                            {
                                whileCondition = ExcuteSteps(WhileCondition);
                                ExcuteSteps(CircleSteps);
                            }
                            i = i + j;
                            break;
                        case "jump to (step loop, step num)":
                            int num = Convert.ToInt32(CurrentStep.Parameterstring);
                            int loop = Convert.ToInt32(CurrentStep.Parameterstring);
                            if(loop==0)
                            {
                                loop = 1;
                            }
                            SystemInfo.SetValue<bool>("IsJump", true);
                            SystemInfo.SetValue<int>("JumpLoop", loop);
                            SystemInfo.SetValue<int>("JumpStepNum", num);
                            break;
                    }
                } 
                else
                {
                    ExcuteStep1(CurrentStep);
                }
            }
            StepsExcuteLoopNum--;
            return true;
        }
        public static bool CircleExcuteSteps(List<Steps> list)
        {
            return true;
        }
        public static bool ExcuteSteps1(List<Steps> list)
        {
            return true;
        }
        public static bool ExcuteStep1(Steps step)
        {
            return true;
        }
        public bool IsNeedJump()
        {
            bool _isJump = SystemInfo.GetValue<bool>("IsJump");
            int _jumpLoop = SystemInfo.GetValue<int>("JumpLoop");
            if (_isJump)
            {
                if (_jumpLoop == StepsExcuteLoopNum)
                {
                    return true;
                }
            }
            return false;
        }
    }
    class Step
    {
        public int StepNum{get;set;}
        public string CategoryName{get;set;}
        public string FounctionName{get;set;}
        public string Parameterstring{get;set;}
        public string FunctionDescr { get; set; }
        public bool IsChecked{get;set;}     
        public bool IsShow{get;set;}
    }
    class Steps
    {
        public int StepsNum { get; set; }
        public List<Step> StepList = new List<Step>();
        public Steps()
        {
            StepsNum = 0;
            StepList.Clear();
        }
    }
}
